from __future__ import unicode_literals

from django.db import models
from decimal import Decimal
# Create your models here.
class Doctor(models.Model):
   d_user_name = models.CharField(max_length = 35 )
   d_first_name =  models.CharField(max_length = 35)
   d_last_name = models.CharField(max_length = 35)
   d_password = models.CharField(max_length = 35)
   def __unicode__(self):
      return self.d_user_name
class Docmgr(models.Model):
   p_id = models.IntegerField(default = -1)
   d_id = models.IntegerField(default = -1)
   calories = models.DecimalField(max_digits=20,decimal_places=2,default=Decimal('0.00'))
   def __unicode__(self):
      return self.p_id
