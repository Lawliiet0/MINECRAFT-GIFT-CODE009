from django.shortcuts import render
from django.http import HttpResponse
from doctor.functions import findall,finddata,savedata,updatedata,deldata,findallif
from doctor.models import Doctor,Docmgr
from patients.models import Patient
# Create your views here.
def index(request):
    return render(request, 'doctor/index.html')
def regpage(request):
    return render(request, 'doctor/register.html')
def reg_store(request):
    if request.method == 'POST':
       username = request.POST['username']
       firstname = request.POST['firstname']
       lastname = request.POST['lastname']
       pwd = request.POST['passwd']
       print username + firstname + lastname + pwd
    return HttpResponse("reg_store")
def apicreate(request):
    info = "API: api/patient/create/<br>Function: help doctor to create a patient in database"
    return HttpResponse(info)
def apiread(request,uid):
    info = "API: api/patient/id/<br>Function: help doctor to get infomation on a patient from database"
    return HttpResponse(info)
def apiupdate(request,uid,update):
    info = "API: api/patient/id/update/<br>Function: help doctor to update infomation on a patient from database"
    return HttpResponse(info)
def apidelete(request,uid,delete):
    info = "API: api/patient/id/delete/<br>Function: help doctor to delete infomation on a patient from database"
    return HttpResponse(info)

