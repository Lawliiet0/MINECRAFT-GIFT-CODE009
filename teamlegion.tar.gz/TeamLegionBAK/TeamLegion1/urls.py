"""TeamLegion URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url
from django.contrib import admin
from doctor import views as doctor_views # import doctor

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^patients/', include('patients.urls')),
    #docktor
    url(r'^doctor/$',doctor_views.index,name = "doctorpage"),
    url(r'^doctor/regpage/$',doctor_views.regpage,name = "doctorregpage"),
    url(r'^doctor/regstore/$',doctor_views.reg_store,name = "doctorregstore"),
    url(r'^api/patient/create/$',doctor_views.apicreate,name = "create"),
    url(r'^api/patient/(\d+)/$',doctor_views.apiread,name = "read"),
    url(r'^api/patient/(\d+)/(update)/$',doctor_views.apiupdate,name = "update"),
    url(r'^api/patient/(\d+)/(delete)/$',doctor_views.apidelete,name = "delete"),
    
]
