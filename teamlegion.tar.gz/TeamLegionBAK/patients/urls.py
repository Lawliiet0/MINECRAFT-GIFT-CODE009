from django.conf.urls import url
from . import views

urlpatterns = [
    # /patients/
    url(r'^$', views.index, name= 'index' ),

    # /patients/324             :: Where 324 is a Patient ID
    url(r'^(?P<patient_id>[0-9]+)/$', views.detail, name= 'detail'),

    # /patients/create
    url(r'^create/', views.create, name= 'create'),

    # /patients/update
    url(r'^update/', views.update, name= 'update'),

    # /patients/delete
    url(r'^delete/', views.delete, name= 'delete'),

]