from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def index(request):
    return HttpResponse("<h1> This is the patients app homepage</h1>")

def detail(request, patient_id):
    return HttpResponse("<h2> Details for Patient_id: " +str(patient_id) + "</h2>")

def create(request):
    return HttpResponse("<h3> Create Patient Entries Page </h3>")

def update(request):
    return HttpResponse("<h3> Update Patient Entries Page </h3>")

def delete(request):
    return HttpResponse("<h4> Delete Patient Entries Page </h4>")