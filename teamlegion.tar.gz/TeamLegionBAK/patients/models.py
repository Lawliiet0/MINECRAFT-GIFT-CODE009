from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Patient(models.Model):
    p_first_name = models.CharField(max_length = 35)
    p_last_name = models.CharField(max_length = 35)
    p_birth_date = models.CharField(max_length = 35)

