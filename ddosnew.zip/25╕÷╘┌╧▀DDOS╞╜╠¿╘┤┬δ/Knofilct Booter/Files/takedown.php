
<object width="100%" height="100%"><param name="movie" value="mgtd.swf"><embed src="mgtd.swf" width="100%" height="100%"></embed></object> 