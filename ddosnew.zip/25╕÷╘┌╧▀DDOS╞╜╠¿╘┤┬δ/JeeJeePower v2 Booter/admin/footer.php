<?php
if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
	</div>
<!-- Start Footer-->
<div id="footer">
  Copyright &copy;<?php echo date('Y').' '.$core->site_name;?><br />
</div>
</div>
<!-- End Footer-->
</body></html>