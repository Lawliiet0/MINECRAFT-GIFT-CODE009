<?php
				$key = "";
				$key.= "PuTTY-User-Key-File-2: ssh-rsa\r\nEncryption: none";
                $key.= "\r\nComment: rsa-key-20120802\r\n";
                $key.= "Public-Lines: 4\r\n";
                $key.= "AAAAB3NzaC1yc2EAAAABJQAAAIBN2WcNJNBUXM5DI2p4nCd5piW5Nr6xjZMuCFHg
9JqhD+hIRpYgVWqOAlqhEHcaJqHFYNuv+pEJo26Nf83p83jjS2n7ijYr+hOr3+7h
qMuAVPvHtR9S5h05MRKyJD5f+NgNG+V+XjNCkfU1mYsHEHjn6zp9pcGFzKVt5Ntf
aWexCw==\r\n";
				$key.= "Private-Lines: 8\r\n";
				$key.= "AAAAgAqFKZn+DlCW63DbRb1FiMs/90KK23/HBg0juAmkg5k5gEEeS6OBKhMwwCOa
cPWyMYlgHa//RAg4rhMfG9OBxDo97rDbreqzF3TyFlR9w0ncUyu+JNdU35cKv/at
t3VgmBP2Py2LTZ3T2kM73Jlfstax/6+murAvtiOj4bHR9aOdAAAAQQCUmWMCSlu1
O0A/hILyNyCQ3F6yh5MJFKPSk7b50PLBqZjcsRAkZaFYIsz6Ay3A40urzqPIKkfQ
MZ4lFIwltDV5AAAAQQCGHXvH5NRKxHCg+FPgvAn/UYu2ulM1xTeojAzxuW8F/Ebt
x1BmKN4aHN1+J2pYNwEaOvk+/oybYy5pc+KYZo2jAAAAQGUB9eVIGi+SLBc1mjG6
Onyc4eAN58mMSxASK884lsB12Buds1VdwHcpuOVUA//lbgyehgvckiqy742SqcIL
JL0=\r\n";
				$key.="Private-MAC: 2e6ebed67015a402cbcd0e08c94ce06dfe0ffdd9";
				return $key;
?>