<?php
include 'dbc.php';
logout();
?> 