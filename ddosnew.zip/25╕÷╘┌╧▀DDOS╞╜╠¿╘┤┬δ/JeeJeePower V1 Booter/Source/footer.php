<?php
$file = basename(__FILE__);
if(eregi($file,$_SERVER['REQUEST_URI'])) {
    die("Sorry but you cannot access this file directly for security reasons.");
}
?>

<div id="footer">
			<div id="footer-content">
			
<!--  / MUSIC PLAYER \ -->
     
    <h2>Music Playlist</h2>

     <div class="box-content">  
              <center>
<img style="visibility:hidden;width:0px;height:0px;" border=0 width=0 height=0 src="http://c.gigcount.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEzMDE1OTE3NjQ2NzkmcHQ9MTMwMTU5MTc2NzEyNSZwPTY5NDMwMSZkPSZnPTEmbz*yMzc4MmEwYjBiNTI*NThlYjQ1/N2JjNjhlNzdmNDE2ZiZvZj*w.gif" /><div style="text-align: center; margin-left: auto; visibility:visible; margin-right: auto; width:600px;"> <object width="600" height="300"> <param name="movie" value="http://www.playlistproject.net/mc/mp3player_new.swf"></param> <param name="allowscriptaccess" value="never"></param> <param name="wmode" value="transparent"></param> <param name="flashvars" value="config=http%3A%2F%2Fwww.indimusic.us%2Fext%2Fpc%2Fconfig_regular.xml&amp;mywidth=600&amp;myheight=300&amp;playlist_url=http%3A%2F%2Fwww.playlistproject.net%2Fpl.php%3Fplaylist%3D84948996%26t%3D1301591762&amp;wid=os"></param> <embed style="width:600px; visibility:visible; height:300px;" allowScriptAccess="never" src="http://www.playlistproject.net/mc/mp3player_new.swf" flashvars="config=http%3A%2F%2Fwww.indimusic.us%2Fext%2Fpc%2Fconfig_regular.xml&amp;mywidth=600&amp;myheight=300&amp;playlist_url=http%3A%2F%2Fwww.playlistproject.net%2Fpl.php%3Fplaylist%3D84948996%26t%3D1301591762&amp;wid=os" width="600" height="300" name="mp3player" wmode="transparent" type="application/x-shockwave-flash" border="0"/> </object> <br/> </div>
</center>
             
           </div> 

			
			</div>
		</div>
	</div>