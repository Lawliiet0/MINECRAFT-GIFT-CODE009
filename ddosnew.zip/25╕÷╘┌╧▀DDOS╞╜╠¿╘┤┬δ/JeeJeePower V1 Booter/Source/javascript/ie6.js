DD_belatedPNG.fix(".css selector");
DD_belatedPNG.fix(".twitterBox");
DD_belatedPNG.fix("img");
DD_belatedPNG.fix(".welcomeBox a");
DD_belatedPNG.fix(".whatBox a");
DD_belatedPNG.fix(".serviceBox a");
DD_belatedPNG.fix(".ourblogBox a");
DD_belatedPNG.fix(".companyBox a");
DD_belatedPNG.fix(".buttons a");
