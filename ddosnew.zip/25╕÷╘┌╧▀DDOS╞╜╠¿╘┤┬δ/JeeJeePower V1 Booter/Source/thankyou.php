     <!--  / Favicon \ -->	
       <link rel="icon" type="image/png" href="images/favicon1.png" />
     <!--  \ Favicon / -->
<meta http-equiv="Refresh" content="5; url=login.php"> 
<link rel="stylesheet" href="style2.css" type="text/css">
<title>Thanks you</title>
<div class="box">


    <h2>&nbsp;</h2>
    <h1><font color="#5b5b5b">Thanks You
</font></h2>

    <p>&nbsp;</p>
    <div class="box-content">
<table width="100%" border="0" cellspacing="0" cellpadding="5" class="main">
  <tr> 
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr> 
    <td width="160" valign="top"><p>&nbsp;</p>
      <p>&nbsp; </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
    <td width="732" valign="top">
      <h4>Your registration is now complete!</h4>
      <p>&nbsp;</p>
      <p><font size="2" face="Arial, Helvetica, sans-serif"><span style="line-height:1.5em;">Your request to join the community has been submitted. An administrator will shortly either approve or deny of this request. If you are a paid customer, please contact the webmaster and notify him. This is a moderated registration community, meaning only approved members will be given access. If you are ready to login, please click <a href="login.php"></a>!texte</span></font></p> <br />
      <p>&nbsp;</p>
      <center><b><u><h3>You will be redirected in 5 secondes !</h3></u></b></center>
	   
      <p align="right">&nbsp; </p></td>
    <td width="196" valign="top">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3">&nbsp;</td>
  </tr>
</table>
</div>
</div>