<?php

// database settings
$db_host = "localhost";
$db_user = "a3111179";
$db_pass = "Lollipop1";
$db_name = "volcanic_database";

?>