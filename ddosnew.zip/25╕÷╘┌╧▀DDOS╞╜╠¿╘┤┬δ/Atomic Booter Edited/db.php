<?php

// database settings
$db_host = "localhost";
$db_user = "a3111179";
$db_pass = "Jinsin1";
$db_name = "volcanic_database";

?>